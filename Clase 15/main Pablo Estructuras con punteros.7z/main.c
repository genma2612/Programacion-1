#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int a;//en momeria vale 4
    char b;//en memoria vale 1
}dato;

int main()
{
 /*   dato d;
    d.a=5;
    d.b='<';

    dato* pDato;
    pDato=&d;

    printf("%d --- %c \n",/*(*pDato).a,(*pDato).b)pDato->a,pDato->b);*/






    int i;
    dato l[2]={{1,'a'},{1,'b'}};
    dato* pLista

    for (i=0;1<2;i++)
    {
        printf("%d --- %c \n",(*(pLista+i)).a,(*(pLista+i)).b);
        printf("%d --- %c \n",(pLista+i)->a,(pLista+i)->b);

    }

    printf("--------------------------------------------------------------------\n\n");
    printf("TAM : %d\n", sizeof(int)); //tama�ao que repsenta en memoria( no es exacta le suma 3 CREO)
    printf("%d --- %c",d.a,d.b);
    return 0;
}
